package my_linked_list;

public class Node {
    public String val;
    public Node prev;
    public Node next;

    public Node(String val) {
        this.val = val;
    }
}
